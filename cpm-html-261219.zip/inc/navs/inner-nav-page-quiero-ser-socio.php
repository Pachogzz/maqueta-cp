		<section class="inner-nav-page pb-5 bg-white">
			<div class="container">
				<div class="row text-center">
					<div class="col-12 col-lg z-index-1">
						<a href="#" class="btn btn-primary btn-lg btn-block rounded-pill w-100 w-lg-75 mx-auto p-3 mb-2 mb-lg-0 active">
							Quiero ser socio <i class="fa fa-chevron-circle-right"></i>
						</a>
					</div>
					<div class="col-12 col-lg p-0 pl-md-0 pl-lg-3 mb-2 mb-lg-0 white-circle-n-line">
						<a href="beneficios.php" class="btn bg-tertiary btn-lg btn-block w-100 rounded-0 py-3 px-0 text-white">
							Beneficios
						</a>
					</div>
					<div class="col-12 col-lg p-0 mb-2 mb-lg-0 ">
						<a href="requisitos.php" class="btn bg-primary btn-lg btn-block w-100 rounded-0 py-3 px-0 text-white">
							Requisitos
						</a>
					</div>
					<div class="col-12 col-lg p-0 mb-2 mb-lg-0 ">
						<a href="soy-menor-de-edad.php" class="btn bg-quaternary btn-lg btn-block w-100 rounded-0 py-3 px-0 text-white">
							Soy menor de edad
						</a>
					</div>
					<div class="col-12 col-lg p-0 mb-2 mb-lg-0 ">
						<a href="como-ser-socio-cumplidor.php" class="btn bg-quinary btn-lg btn-block w-100 rounded-0 py-3 px-0 text-white">
							¿Cómo puedo ser socio?
						</a>
					</div>
				</div>
			</div>
		</section> <!-- /. Inner Nav Home Quiero ser Socio -->