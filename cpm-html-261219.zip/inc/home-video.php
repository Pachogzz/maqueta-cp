		<section id="home-slider" class="styled-carousel haz-flange after-flange">
			<div class="home-slider">
				<div id="mainSlideNav" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner">
						<div class="carousel-item active align-items-center">
							<video autoplay loop muted class="video-bg container-fluid px-0" id="video-bg">
								<source 
									class="d-block w-100"
									src="https://content.jwplatform.com/videos/gplKz4H0-j7VkahGy.mp4" 
									type="video/mp4" 
									alt="Bienvenido a Caja Popular Mexicana">
							</video>
							<div class="carousel-caption d-none d-md-block p-5 py-md-2 p-lg-5 bg-primary text-white text-left br-ntl-30 col-6 col-lg-3 my-auto has-label">
								<h2 class="display-5 font-weight-bold">Bienvenido a Caja Popular Mexicana.</h2>
							</div>
						</div>
				</div>
		</section> <!-- /. Slider Home -->