		<footer id="site-footer" class="py-5 border-top">
			<div class="container">
				<div class="row">
					<!-- <div class="d-none d-lg-block d-xl-block col-1"></div> -->
					<div class="col-md-6 col-lg-7 offset-lg-1">
						<h5>¡Queremos escucharte! Llámanos al </h5>
						<h2>800 7100 800</h2>
						<h5>o escríbenos a </h5>
						<h2><a href="mailto:contacto@cpm.coop">contacto@cpm.coop</a></h2>
						<a href="#"><img src="assets/img/buro-g-logo.jpg" alt="" class="img-fluid"></a>
						<a href="http://www.aciamericas.coop/" target="_blank"><img src="assets/img/coop-g-logo.jpg" alt="" class="img-fluid"></a>
						<a href="http://www.woccu.org/" target="_blank"><img src="assets/img/cm-g-logo.jpg" alt="" class="img-fluid"></a>
						<a href="http://concamex.coop/es-mx/" target="_blank"><img src="assets/img/concamex-g-logo.jpg" alt="" class="img-fluid"></a>
					</div>
					<div class="col-md-6 col-lg-3">
						<ul class="social-icons pt-3 pt-md-0 text-right">
							<li><a href="https://www.facebook.com/CajaPopularMexicana/" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
							<li><a href="https://twitter.com/CajaMexicana" target="_blank"><i class="fab fa-twitter"></i></a></li>
							<li><a href="https://www.youtube.com/user/CajaPopularMexicana" target="_blank"><i class="fab fa-youtube"></i></a></li>
							<li><a href="https://www.linkedin.com/company/caja-popular-mexicana/" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
						</ul>
					</div>
					<!-- <div class="d-none d-lg-block d-xl-block col-1"></div> -->
				</div>
			</div>
		</footer> <!-- /. Site Footer -->

		<section id="copyright" class="bg-tertiary py-3">
			<div class="container">
				<div class="row">
					<div class="col-12 mb-2 text-center">
						<ul class="nav justify-content-center">
							<a class="nav-link p-0 mr-1 text-light" href="#"><small>Consulta los costos y comisiones de nuestros productos |</small></a>
							<a class="nav-link p-0 mr-1 text-light" href="#"><small>Políticas de uso |</small></a>
							<a class="nav-link p-0 mr-1 text-light" href="#"><small>Mapa del sitio |</small></a>
							<a class="nav-link p-0 mr-1 text-light" href="#"><small>Aviso de privacidad |</small></a>
							<a class="nav-link p-0 mr-1 text-light" href="#"><small>Despacho de Cobranza |</small></a>
							<a class="nav-link p-0 mr-1 text-light" href="#"><small>Aviso de privacidad crédito y cobranza |</small></a>
							<a class="nav-link p-0 mr-1 text-light" href="#"><small>Términos de uso para redes sociales |</small></a>
							<a class="nav-link p-0 mr-1 text-light" href="#"><small>Aviso de privacidad en redes sociales</small></a>
						</ul>
					</div>
					<div class="col-12 text-center text-light"><small>&copy; Caja Popular Mexicana 2020</small></div>
				</div>
			</div>
		</section>

		<!-- JavaScript Libraries -->
		<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
		<script src="https://kit.fontawesome.com/0f2dd2d9af.js" crossorigin="anonymous"></script>
		<script src="assets/js/site.js"></script>
	</body>
</html>